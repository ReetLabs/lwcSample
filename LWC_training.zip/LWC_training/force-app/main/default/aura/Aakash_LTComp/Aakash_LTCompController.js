({
	clickme : function(component, event, helper) {
	//	alert('Button clicked');
      //  console.log('The button is clicked');
      var showcolor = component.get("v.color");
       // alert(showcolor);
       var abc="Success";
      component.set("v.color",abc);
        component.set("v.picklist",["1","2","3","4","5"]);
        component.set('v.columns', [
            {label: 'Firstname', fieldName: 'firstname', type: 'text'},
            {label: 'Lastname', fieldName: 'lastname', type: 'text'}]);
        var action = component.get("c.getmycontacts");
        action.setCallback(this,function(response)
                           {
                              var rep = response.getReturnValue(); 
                             //  alert(JSON.stringify(rep));
                              component.set("v.Showcon",rep);
                           }
                          );
        $A.enqueueAction(action);
      
        //alert(component.get("v.Showcon"));
        
	},
    
    doInit : function(component, event, helper)
    {
          
    }
})