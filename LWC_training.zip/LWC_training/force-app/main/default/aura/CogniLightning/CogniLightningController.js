({
	clickme : function(component, event, helper) {
		//alert('Button Clicked');
		console.log("Button CLicked");
      var c = component.get("v.color");
        console.log("Button Color is"+c);
        if(c=="brand")
        {
            component.set("v.color","success");
        }
        else
        {
            component.set("v.color","brand");
        }
        
	},
    doInit : function(component, event, helper) {
       // alert('page load');
       var callevent = component.getEvent('cmpEvent');
        callevent.setParams({
            "msg" : "A component event fired" });
        callevent.fire();
        
        
        component.set("v.col",[{label:'Account name', fieldName:'name' ,type:'text'},{label:'Billing Country' ,fieldName:'billingcountry' ,type:'text'}]);
       var action = component.get("c.getAllAccounts");
        action.setCallback(this, function(response){
            var result = response.getReturnValue();
            //alert(result);
            component.set("v.acc",JSON.stringify(result));
            
        });
        $A.enqueueAction(action);
    },
    
    handleComponentEvent : function(component, event, helper){
        var msg1 = event.getParams('msg');
        alert(JSON.stringify(msg1));
        component.set('v.Message',JSON.stringify(msg1));
    }
})