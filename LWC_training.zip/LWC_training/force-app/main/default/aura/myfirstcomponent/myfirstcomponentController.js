({
	clickme : function(component, event, helper) {
		//alert('The button is clicked');
		var a = component.get("v.color");
        console.log("the variant was "+ a);
        component.set("v.color","Success")
        var action = component.get('c.show');
        action.setCallback(this,function(response){
            var result = response.getReturnValue();
            component.set("v.mycontacts",result);
            alert(result);
        });
$A.enqueueAction(action);
	}
})