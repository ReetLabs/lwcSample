({
	clickme : function(component, event, helper) {
		//alert('The button is clicked');
		console.log("The button is clicked");
        var color = component.get("v.color");
        console.log("The current value is "+ color);
        color = "Success";
        component.set("v.color",color);
        component.set("v.heading","You have clicked the button and now its green");
	},
    doInit : function(comp,event,helper)
    {
        comp.set("v.columns",[{label :'Account Name',fieldName:'Name',type:'text'},
                             {label :'Account Country',fieldName:'billingCountry',type:'text'}]);
    //alert('The button is clicked');
    //call the data fromm apex by using callback method
    var action = comp.get("c.show");
        // skip for now - action.setParams in jason format
        // 
        action.setCallback(this,function(response){
            var myAccounts = response.getReturnValue();
            comp.set("v.MyAccounts",myAccounts);
            alert(JSON.stringify(myAccounts));
        });
        
        $A.enqueueAction(action);
                           
                           
}
})