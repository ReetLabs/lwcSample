import { LightningElement, wire } from 'lwc';
import AccountData from '@salesforce/messageChannel/accountDataChannel__c'
import {subscribe,
    unsubscribe,
    MessageContext,APPLICATION_SCOPE } from 'lightning/messageService';

import { registerListener,unregisterAllListners } from 'c/pubsub';
import { CurrentPageReference } from 'lightning/navigation';



export default class Component2 extends LightningElement {
    AccName='';
    AccId='';
    accName='';
    @wire(MessageContext)messageContext;
    @wire(CurrentPageReference)pageref;
    handleclicknew()
    {
      registerListener('myPubEvent',this.acccaptre,this);
    }
    handlesub()
    { 
        console.log("Button clicked");




         this.subscription = subscribe(
            this.messageContext,
            AccountData,
            (payload) => {
              this.handleMessage(payload);
            },{scope: APPLICATION_SCOPE});
          
         
          console.log("test",JSON.stringify(payload));
        } 
        handleMessage(payload)
        {
          this.AccName = payload.name;
          this.AccId=payload.recorId;
        }
       
          
          
        acccaptre(payload)
        {
          this.AccId =payload.recId;
          this.accName=payload.name;
        }
    disconnectedCallback()
    {
      unregisterAllListners(this);
        unsubscribe(this.subscription);
        this.subscription = null;
    }

}