import { api, LightningElement } from 'lwc';

export default class BikeTile extends LightningElement {
   @api bike ;
 
}