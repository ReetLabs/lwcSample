import { api, LightningElement } from 'lwc';
//import ACC_Name from '@salesforce/schema/Account.Name';
import {ShowToastEvent} from 'lightning/platformShowToastEvent';
export default class AccountPageComp extends LightningElement {
    @api recordId;
handleClear(event)
{
const inputfields =this.template.querySelectorAll('lightning-input-field');
if(inputfields) {
    inputfields.forEach(field =>{field.reset()});
}
this.dispatchEvent(
    new ShowToastEvent(
        {
            title:'Account lwc Component',
            message:'Input fields has been cleard and set to default values',
            variant:'Success',
        }
    ),
);
}
handleSuccess(event)
{
    this.dispatchEvent(
        new ShowToastEvent(
            {
                title:'Record Updated',
                variant:'Success',
            }
        ),
    );
    
}
}