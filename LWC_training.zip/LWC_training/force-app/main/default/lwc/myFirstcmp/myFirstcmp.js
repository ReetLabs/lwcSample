import { LightningElement } from 'lwc';

export default class MyFirstcmp extends LightningElement {
    display ='Your input text wil appear here !';
   // secondvar='';
    handleOnchange(event)
{
    this.display= event.target.value;
}
    handleClickMe()
    {
//alert('This is a button test click');
window.console.log("Submit button click");
//this.display = this.secondvar;
    }
}