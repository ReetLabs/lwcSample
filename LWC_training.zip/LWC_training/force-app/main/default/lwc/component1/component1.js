import { LightningElement, wire } from 'lwc';
import findAccId from '@salesforce/apex/FindAccountHandler.findAccId';
import { publish,MessageContext } from 'lightning/messageService';
import AccountData from '@salesforce/messageChannel/accountDataChannel__c'
import { fireEvent } from 'c/pubsub';
import { CurrentPageReference } from 'lightning/navigation';
export default class Component1 extends LightningElement {
accName='';
AccId=undefined;
testfield='send value';
    handleInput(event)
    {
this.accName = event.detail.value;
//this.AccId=account;
console.log("output",this.account);
    }
@wire(findAccId,{Accname:'$accName'})account({data})
{
    if(data)
    {this.AccId =data;

    }
}
@wire(MessageContext)messageContext;
@wire(CurrentPageReference)Pageref;

handlePublish()
{
    const pay ={'recId':this.AccId,'name':this.accName};
    console.log("Accidvalue",this.AccId);
    fireEvent(this.Pageref,'myPubEvent',pay);

    const payload={
        recordId:this.AccId,
        name:this.accName
    };
    publish(this.messageContext,AccountData,payload);
    console.log("published");
}
}