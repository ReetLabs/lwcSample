import { LightningElement, wire } from 'lwc';
import getbikedetails from '@salesforce/apex/ApexBikeController.getBikedetails';
export default class BIkeShop extends LightningElement {
    search='';
    lowerlim =0;
    upperlim=100000;
    record;
    error;
    
    handleclear()
    {
        this.search='';
    this.lowerlim =0;
    this.upperlim=0;
    }
    handleSearch(event)
    {
        this.search=event.detail.value;
    }
    handlelowerlim(event)
    {
        
            this.lowerlim=event.target.value;
        
        
       window.console.log("Record",this.record);
    }
    handleupperlim(event)
    {
        this.upperlim=event.detail.value;
    }
handlecheck()
{
    console.log("search",this.search);
    console.log("Lowerlim",this.lowerlim);
    console.log("upperlim",this.upperlim);

}
    @wire(getbikedetails,{search:'$search',lowerlim:'$lowerlim',upperlim:'$upperlim'})Bikes({data,error}){
        if(data)
        {
            this.record=data;
            elseif(error)
            {
this.error=error;
            }
        }
    }


}