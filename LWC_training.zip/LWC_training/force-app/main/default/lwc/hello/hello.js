import { LightningElement } from 'lwc';
import { createRecord } from 'lightning/uiRecordApi';
import ACCOUNT_OBJECT from '@salesforce/schema/Account'
import ACCOUNT_NAME from '@salesforce/schema/Account.Name'
import AccountId from '@salesforce/schema/Case.AccountId';
export default class Hello extends LightningElement {
    myvariable = "Testing";
    accid;
    name='';
//handleNamechange(Event)
//{
   // this.accid = undefined;
   // this.name=event.target.value;

//}
onCreateclick()
{
    const fields={};
fields[ACCOUNT_NAME.fieldApiName]=this.name;
const recordinput ={apiName:ACCOUNT_OBJECT.objectApiName,fields};
createRecord(recordinput);
}
}