import { api, LightningElement } from 'lwc';
import { createRecord } from 'lightning/uiRecordApi';
import ACC_OBJECT from '@salesforce/schema/account';
import {ShowToastEvent} from 'lightning/platformShowToastEvent';
import ACC_NAME from '@salesforce/schema/Account.Name';
import { NavigationMixin } from 'lightning/navigation';

export default class Simpleinput extends NavigationMixin(LightningElement) {
name='';
@api recordId;
accId=undefined;
url;
connectedCallback()
{
this.accountref ={
    
        type: 'standard__objectPage',
        attributes: {
            
            objectApiName: 'Account',
            actionName: 'home'
        }
};
}
handleAcc(event)
{
    this.name=event.target.value;
}
handleClick()
{
    const fields ={};
    fields[ACC_NAME.fieldApiName]=this.name;
    const recordInput = {apiName:ACC_OBJECT.objectApiName,
    fields};
    createRecord(recordInput).then(account=>{this.accId=account.id;
    this.dispatchEvent(
        new ShowToastEvent({title:'success',
    message:'The acccount is created :'+ this.accId,
variant:'success',}),
    );});
    this[NavigationMixin.Navigate]({
        type: 'standard__recordPage',
        attributes: {
            recordId :this.accId,
            objectApiName: 'Account',
            actionName: 'view'
        }
    });
    
}
handleHome()
{
    this[NavigationMixin.Navigate](this.accountref);
}
handlerelatedlist()
{
    console.log("recordID",this.recordId);
    this[NavigationMixin.Navigate]({
        type: 'standard__recordRelationshipPage',
        attributes: {
            recordId: this.recordId,
            objectApiName: 'Account',
            relationshipApiName: 'AccountTeamMembers',
            actionName: 'view'
        }
    });
}
}