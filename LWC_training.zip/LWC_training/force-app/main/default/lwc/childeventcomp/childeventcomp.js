import { LightningElement,api } from 'lwc';

export default class Childeventcomp extends LightningElement {
   @api contact;

selectHandler(event)
{event.preventDefault();
   

const mycustEvent = new CustomEvent('mycustomevent',{
    detail :this.contact.Id
});
this.dispatchEvent(mycustEvent);
}
}