import { LightningElement,wire } from 'lwc';
import { fireEvent } from 'c/pubsub';
import { CurrentPageReference } from 'lightning/navigation';
export default class Testing extends LightningElement {
    testfield='testing';
    @wire(CurrentPageReference)pageref;

    handleclick()
    {
        fireEvent(this.pageref,'evt',this.testfield);
    }
}